import React from "react";
import Lab from "./Lab.jsx";

export default function App() {
  return <Lab />;
}
